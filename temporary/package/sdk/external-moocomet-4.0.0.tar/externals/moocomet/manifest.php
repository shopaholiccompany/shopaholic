<?php return array(
  'package' => array(
    'type' => 'external',
    'name' => 'moocomet',
    'version' => '4.0.0',
    'revision' => '$Revision: 6973 $',
    'path' => 'externals/moocomet',
    'repository' => 'socialengine.net',
    'meta' => array(
      'title' => 'Moocomet',
      'author' => 'Webligo Developments',
    ),
    'directories' => array(
      'externals/moocomet',
    )
  )
) ?>