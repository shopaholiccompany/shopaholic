<?php return array(
  'package' => array(
    'type' => 'external',
    'name' => 'autocompleter',
    'version' => '4.0.0',
    'revision' => '$Revision: 6973 $',
    'path' => 'externals/autocompleter',
    'repository' => 'socialengine.net',
    'meta' => array(
      'title' => 'Autocompleter',
      'author' => 'Webligo Developments',
    ),
    'directories' => array(
      'externals/autocompleter',
    )
  )
) ?>