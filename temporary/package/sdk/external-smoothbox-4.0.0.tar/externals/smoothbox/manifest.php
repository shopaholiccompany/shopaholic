<?php return array(
  'package' => array(
    'type' => 'external',
    'name' => 'smoothbox',
    'version' => '4.0.0',
    'revision' => '$Revision: 6973 $',
    'path' => 'externals/smoothbox',
    'repository' => 'socialengine.net',
    'meta' => array(
      'title' => 'Smoothbox',
      'author' => 'Webligo Developments',
    ),
    'directories' => array(
      'externals/smoothbox',
    )
  )
) ?>