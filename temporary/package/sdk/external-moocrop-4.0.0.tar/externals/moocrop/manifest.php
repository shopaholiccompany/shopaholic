<?php return array(
  'package' => array(
    'type' => 'external',
    'name' => 'moocrop',
    'version' => '4.0.0',
    'revision' => '$Revision: 6973 $',
    'path' => 'externals/moocrop',
    'repository' => 'socialengine.net',
    'meta' => array(
      'title' => 'Moocrop',
      'author' => 'Webligo Developments',
    ),
    'directories' => array(
      'externals/moocrop',
    )
  )
) ?>