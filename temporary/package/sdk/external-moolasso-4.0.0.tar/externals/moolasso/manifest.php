<?php return array(
  'package' => array(
    'type' => 'external',
    'name' => 'moolasso',
    'version' => '4.0.0',
    'revision' => '$Revision: 6973 $',
    'path' => 'externals/moolasso',
    'repository' => 'socialengine.net',
    'meta' => array(
      'title' => 'Moolasso',
      'author' => 'Webligo Developments',
    ),
    'directories' => array(
      'externals/moolasso',
    )
  )
) ?>