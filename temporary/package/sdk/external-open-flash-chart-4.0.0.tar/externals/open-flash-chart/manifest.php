<?php return array(
  'package' => array(
    'type' => 'external',
    'name' => 'open-flash-chart',
    'version' => '4.0.0',
    'revision' => '$Revision: 6973 $',
    'path' => 'externals/open-flash-chart',
    'repository' => 'socialengine.net',
    'meta' => array(
      'title' => 'Open Flash Chart',
      'author' => 'Webligo Developments',
    ),
    'directories' => array(
      'externals/open-flash-chart',
    )
  )
) ?>