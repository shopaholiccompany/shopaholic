<?php return array(
  'package' => array(
    'type' => 'external',
    'name' => 'flowplayer',
    'version' => '4.0.0',
    'revision' => '$Revision: 6973 $',
    'path' => 'externals/flowplayer',
    'repository' => 'socialengine.net',
    'meta' => array(
      'title' => 'Flow Player',
      'author' => 'Webligo Developments',
    ),
    'directories' => array(
      'externals/flowplayer',
    )
  )
) ?>