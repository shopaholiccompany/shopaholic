<?php return array(
  'package' => array(
    'type' => 'external',
    'name' => 'fancyupload',
    'version' => '4.0.1',
    'revision' => '$Revision: 7305 $',
    'path' => 'externals/fancyupload',
    'repository' => 'socialengine.net',
    'meta' => array(
      'title' => 'Fancy Upload',
      'author' => 'Webligo Developments',
      'changeLog' => array(
        '4.0.1' => array(
          'fancyupload.css' => 'Improved RTL support',
          'FancyUpload2.js' => 'Improved language support',
          'manifest.php' => 'Incremented version',
        ),
      ),
    ),
    'directories' => array(
      'externals/fancyupload',
    ),
  )
) ?>