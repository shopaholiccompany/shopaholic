<?php return array(
  'package' => array(
    'type' => 'external',
    'name' => 'tagger',
    'version' => '4.0.1',
    'revision' => '$Revision: 7305 $',
    'path' => 'externals/tagger',
    'repository' => 'socialengine.net',
    'meta' => array(
      'title' => 'Tagger',
      'author' => 'Webligo Developments',
      'changeLog' => array(
        '4.0.1' => array(
          'manifest.php' => 'Incremented version',
          'tagger.css' => 'Added missing translation',
        ),
      ),
    ),
    'directories' => array(
      'externals/tagger',
    )
  )
) ?>