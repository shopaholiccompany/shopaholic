<?php return array(
  'package' => array(
    'type' => 'external',
    'name' => 'mootree',
    'version' => '4.0.0',
    'revision' => '$Revision: 6973 $',
    'path' => 'externals/mootree',
    'repository' => 'socialengine.net',
    'meta' => array(
      'title' => 'Mootree',
      'author' => 'Webligo Developments',
    ),
    'directories' => array(
      'externals/mootree',
    )
  )
) ?>