<?php return array(
  'package' => array(
    'type' => 'external',
    'name' => 'firebug',
    'version' => '4.0.0',
    'revision' => '$Revision: 6973 $',
    'path' => 'externals/firebug',
    'repository' => 'socialengine.net',
    'meta' => array(
      'title' => 'Firebug Lite',
      'author' => 'Webligo Developments',
    ),
    'directories' => array(
      'externals/firebug',
    )
  )
) ?>